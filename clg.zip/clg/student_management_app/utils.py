from gtts import gTTS
import os

def generate_feedback_audio(feedback_id, feedback_text):
    # Specify the directory for saving audio files
    audio_dir = 'media/feedback_audio/'
    # Ensure the directory exists
    if not os.path.exists(audio_dir):
        os.makedirs(audio_dir)

    # Generate audio file
    tts = gTTS(text=feedback_text, lang='en')
    audio_file_path = os.path.join(audio_dir, f'{feedback_id}.mp3')
    tts.save(audio_file_path)
