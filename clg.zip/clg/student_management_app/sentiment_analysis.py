# sentiment_analysis.py

from transformers import pipeline

# Load the sentiment-analysis model
sentiment_analyzer = pipeline("sentiment-analysis")

def analyze_feedback(feedback_message):
    """Analyze the sentiment of the feedback message."""
    result = sentiment_analyzer(feedback_message)
    sentiment = result[0]['label']
    score = result[0]['score']
    return sentiment, score
